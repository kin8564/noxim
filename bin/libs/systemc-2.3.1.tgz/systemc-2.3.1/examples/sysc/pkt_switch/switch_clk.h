/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2014 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.accellera.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/

/*****************************************************************************

  switch_clk.h - This is the interface file for the synchronous process 
                 "switch_clk".

  Original Author: Rashmi Goswami, Synopsys, Inc.

 *****************************************************************************/

/*****************************************************************************

  MODIFICATION LOG - modifiers, enter your name, affiliation, date and
  changes you are making here.

      Name, Affiliation, Date:
  Description of Modification:

 *****************************************************************************/

#ifndef SWITCH_CLK_H_INCLUDED
#define SWITCH_CLK_H_INCLUDED

#include "systemc.h"

struct switch_clk: sc_module {
      sc_out<bool>   switch_cntrl;
      sc_in_clk CLK;

      SC_CTOR(switch_clk)
        {
           SC_METHOD(entry);
           dont_initialize();
           sensitive << CLK.pos(); 
         }
     void entry();
};
#endif // SWITCH_CLK_H_INCLUDED
